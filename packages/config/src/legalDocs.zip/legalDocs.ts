export type LegalRagDoc = {
  id: string;
  title: string;
  text: string;
  url: string;
};

export const legalRagDocs: LegalRagDoc[] = [
  {
    id: "doc1",
    title: "Protection of Women from Domestic Violence Act, 2005 — Section 18",
    url: "https://legislative.gov.in/sites/default/files/A2005-43.pdf",
    text:
      "PWDVA §18 (Protection orders): A Magistrate may, after hearing the aggrieved person and the respondent and on being prima facie satisfied that domestic violence has taken place or is likely to take place, pass a protection order prohibiting the respondent from committing domestic violence, aiding or abetting domestic violence, entering the aggrieved person’s residence or place of employment, attempting to communicate in any form, alienating assets, causing violence to dependants or relatives, or any other direction necessary for safety. Applications may be presented by the aggrieved person, a Protection Officer, or any other person on her behalf.\nPWDVA §19 (Residence orders): The Magistrate may restrain the respondent from dispossessing the aggrieved person from the shared household, direct removal of the respondent, restrain entry, or secure alternate accommodation.\nPWDVA §§20–22 (Monetary, custody, compensation): The Magistrate may order monetary relief, grant child custody arrangements, and award compensation and damages for injuries.\nPWDVA §31 (Penalty for breach): Failure to comply with a protection order or interim protection order is an offence punishable with imprisonment up to one year, or fine up to twenty thousand rupees, or both."
  },
  {
    id: "doc2",
    title: "Protection of Women from Domestic Violence Rules, 2006 — Rule 8 (Duties of Protection Officers)",
    url: "https://wcd.nic.in/sites/default/files/226349.pdf",
    text:
      "Rule 8 (Protection Officer duties): The Protection Officer must assist the aggrieved person in making an application under PWDVA §12, prepare the Domestic Incident Report (Form I) if she requests, ensure access to legal aid under the Legal Services Authorities Act, 1987, maintain a list of service providers and shelter homes, develop a safety plan including arranging protection orders and other reliefs, and forward copies of the application and any protection order to the jurisdictional police station." 
  },
  {
    id: "doc3",
    title: "PWDVA Handbook for Protection Officers (MWCD 2014) — Filing an Application",
    url: "https://wcd.nic.in/sites/default/files/handbook%20for%20protection%20officers.pdf",
    text:
      "The aggrieved person can approach the Protection Officer, service provider, or directly file an application before the Magistrate under Section 12 seeking reliefs including a protection order under Section 18. The Protection Officer must help her draft the application, collect supporting documents when safe, and submit the Domestic Incident Report along with the application. The Magistrate shall fix the first hearing within three days and may grant an interim or ex parte protection order if immediate protection is required. The Protection Officer is responsible for serving notice on the respondent and ensuring copies of the order reach the aggrieved person and the local police station." 
  },
  {
    id: "doc4",
    title: "National Commission for Women — Helpline and Support Services",
    url: "https://ncw.nic.in/helplines",
    text:
      "The National Commission for Women coordinates the Women Helpline 181 for immediate assistance and links survivors with Protection Officers, legal aid, and counselling services. Survivors may also contact local NGOs recognised under the Protection of Women from Domestic Violence Act for accompaniment to court and follow-up with enforcement of protection orders." 
  },
  {
    id: "doc5",
    title: "Indian Penal Code Section 498A — Cruelty by Husband or Relatives",
    url: "https://indiacode.nic.in/show-data?actid=AC_CEN_5_23_00023_186045_1517807327078&orderno=498A",
    text:
      "IPC §498A (Cruelty by husband or relatives): Whoever being the husband or the relative of the husband of a woman subjects her to cruelty shall be punished with imprisonment for a term which may extend to three years and shall also be liable to fine. ‘Cruelty’ includes any willful conduct likely to drive the woman to commit suicide or cause grave injury, and harassment for unlawful demand for any property or valuable security. The offence is cognizable and non-bailable."
  },
  {
    id: "doc6",
    title: "Indian Penal Code Sections 323 & 325 — Hurt and Grievous Hurt",
    url: "https://indiacode.nic.in",
    text:
      "IPC §323 (Punishment for voluntarily causing hurt): Whoever, except in the cases provided for by section 334, voluntarily causes hurt, shall be punished with imprisonment of either description for a term which may extend to one year, or with fine which may extend to one thousand rupees, or with both. IPC §325 (Punishment for voluntarily causing grievous hurt): Whoever voluntarily causes grievous hurt shall be punished with imprisonment of either description for a term which may extend to seven years, and shall also be liable to fine."
  },
  {
    id: "doc7",
    title: "Indian Penal Code Section 354 — Outraging Modesty",
    url: "https://indiacode.nic.in",
    text:
      "IPC §354 (Assault or criminal force to woman with intent to outrage her modesty): Whoever assaults or uses criminal force to any woman, intending to outrage or knowing it to be likely that he will thereby outrage her modesty, shall be punished with imprisonment of either description for a term which may extend to five years, and shall also be liable to fine."
  }
];
